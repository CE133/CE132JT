/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Employee")
public class Employee {

    /**
     * @param args the command line arguments
     */
    
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Id
    @Column(name="id")
    private int id;
    
    @Column(name="First_name")
    private String firstname;
    
    @Column(name="Last_name")
    private String lastname;
    
    @Column(name="Salary")
    private int Salary;

    public Employee(String fnm, String lnm, int s) {
  //      throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        firstname=fnm;
        lastname=lnm;
        Salary=s;
    
    
    }


    public void Employee()
    {
        
    }
    /*public void Employee(String fnm,String lnm,int s)
    {
        firstname=fnm;
        lastname=lnm;
        Salary=s;
    }
*/
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getSalary() {
        return Salary;
    }

    public void setSalary(int Salary) {
        this.Salary = Salary;
    }
    
    @Override
    public String toString() {
        return "Employee{" + "id=" + id + ", firstName=" + firstname + ", lastName=" + lastname + ", salary=" + Salary + '}';
    }
    
}
